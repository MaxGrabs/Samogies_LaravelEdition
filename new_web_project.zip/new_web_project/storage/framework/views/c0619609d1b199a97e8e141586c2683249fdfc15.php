<?php 
session_start();
?>

<html>
<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
table, th, td {
  border: 1px solid black;
  padding: 3px;
  
}
form{
	margin:auto;
	width: 50%;
}


</style>
</head>
<body>
<?php

echo "<h1> Hello," . $_SESSION["username"] . "</h1>";
?>
<form action="mail" method="get" style="margin: auto; width: 50%;">
<table>

<?php include 'D:\XAMPP\new_web_project\resources\views\SQL_SamPer\connectSqli.blade.php';
//BEACHTUNG!!!!!ATTENTION ^^ CHANGE TO ABSOLUTE PATHING
$total = 0;
for($x = 1; $x <=13; $x++){
$sql = "SELECT * FROM menus_tbl WHERE Id=" . $x;
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
	 while($row = $result->fetch_assoc()) {
		$quan = $_GET[$x];
		if(!$quan == null){
		$price =  $quan * $row["Price"] ;
		echo "<tr>" .
		"<th>" . "<strong>" . $row["Name"]. "</strong>" . "</th> " .
		 "<td> Quantity : <strong>" . $quan ."</strong></td>" .
	  	 "<td>Price <strong>$" . $price . "</strong></td>" ;
		 
		 
		$total = $price + $total;
		
		$itemName[$x] = $row["Name"];
		$itemQuan[$x] = $quan;
		$itemPrice[$x] = $row["Price"];
		
		
	echo
		"Name:" . $itemName[$x] . " --- " .
		"Quantity :" .$itemQuan[$x] . " --- " .
		"Price : $" . $itemPrice[$x]. "<br><br>" 
	;
			
		
		}
	 }
}

}

$_SESSION["varName"] = $itemName;
$_SESSION["varQuan"] = $itemQuan;
$_SESSION["varPrice"] = $itemPrice;
$_SESSION["total"] = $total;
echo "Total: $" . $_SESSION["total"];
?>


</table>
<input type="submit" name="Buy" value="Buy Now" class="btn btn-info" />

</form>



</body>
</html>
<?php /**PATH D:\XAMPP\new_web_project\resources\views/SamPerConfirm.blade.php ENDPATH**/ ?>