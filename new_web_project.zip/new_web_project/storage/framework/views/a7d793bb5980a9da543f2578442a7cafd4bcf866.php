<?php include 'SQL_SamPer\Connect_SamPer.php'; ?>


<html>

<head>
    <title>PHP Login Form with Password Encryption</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>

<body>
    <?php 
        if (!isset($_GET["login"])) {
    ?>
    <br /><br />
    <div class="container" style="width:500px;">
        <h3 align="center">Samosies Register Form</h3>
        <br />
        <h3 align="center">Create An Account</h3>
        <br />

        
        <form method="get" action="<?php echo $_SERVER['PHP_SELF'] ?>">
            <label>First Name </label>
            <input type="text" name="fname" class="form-control" />
            <br />
			<label>Last Name </label>
            <input type="text" name="lname" class="form-control" />
            <br />
			<label>UserName </label>
            <input type="text" name="uname" class="form-control" />
            <br />
            <label>Password</label>
            <input type="password" name="password" class="form-control" />
            <br />
			<label>Email</label>
            <input type="text" name="email" class="form-control" />
            <br />
			<label>Address</label>
            <input type="text" name="address" class="form-control" />
            <br/>
			<label>Credit Card / Debit</label>
            <input type="text" name="card" class="form-control" />
            <br />
            <input type="submit" name="login" value="Register" class="btn btn-info" />
            <br />
            <p align="center"><a href="Login_SamPer.php">Login</a></p>
        </form>
        </div>
        <?php
			}
		
			else{
		
				$fname=$_GET["fname"];
                $lname=$_GET["lname"];
                $uname=$_GET["uname"];
                $passw=$_GET["password"];
                $email=$_GET["email"];
				$address=$_GET["address"];
				$payment=$_GET["card"];
                $passw=md5($passw);
		
				try {
            $sql = "INSERT INTO SAMPER_TBL(fname, lname, usern, pass, mail, address, payment) VALUES ('$fname', '$lname', '$uname', '$passw', '$email', '$address', '$payment')";
            // use exec() because no results are returned
            $conn->exec($sql);

            $last_id = $conn->lastInsertId();
            echo "New record created successfully. Last inserted ID is: " . $last_id;
                } 
                catch (PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
                }
        $conn = null;
        }
    
        ?>
            



</body>

</html><?php /**PATH D:\XAMPP\new_web_project\resources\views/about.blade.php ENDPATH**/ ?>