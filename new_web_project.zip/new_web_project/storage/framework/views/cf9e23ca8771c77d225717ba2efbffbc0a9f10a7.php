<?php include 'D:\XAMPP\new_web_project\resources\views\SQL_SamPer\connectSqli.blade.php';
//BEACHTUNG!!!!!ATTENTION ^^ CHANGE TO ABSOLUTE PATHING
error_reporting(0);
ini_set('display_errors', 0);

session_start();
$itemName = $_SESSION["varName"];
$itemQuan = $_SESSION["varQuan"];
$itemPrice = $_SESSION["varPrice"];



echo "<h1>Thank you for shopping at Samosies =) " . $_SESSION["username"] . " </h1>" .
"<img src='php.png' alt='logo'>" .  "<br>";
$sql = "SELECT * FROM samper_tbl WHERE id= " . $_SESSION["id"] ;
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
	$email = $row["mail"];
	$first = $row["fname"];
	$last = $row["lname"];
	$username = $row["usern"];
}
}
$emailContent = "Your Receipt: <br> ";
for($x = 1; $x <=11; $x++){
	
	if (! $itemQuan[$x] == null){
		$emailContent .= $itemName[$x] . ":  (" ;
		$emailContent .= $itemQuan[$x] . ")  $" ;
		$emailContent .= $itemPrice[$x] . " <br> " ;
	}
	
}
$emailContent .= "Total: $" . $_SESSION["total"] . " <br> ";

echo $emailContent;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//BEACHTUNG!!!!!ATTENTION
//change the requires with absolute pathing apparently
require 'D:\XAMPP\new_web_project\resources\views\PHPMailer-master/src/Exception.php';
require 'D:\XAMPP\new_web_project\resources\views\PHPMailer-master/src/PHPMailer.php';
require 'D:\XAMPP\new_web_project\resources\views\PHPMailer-master/src/SMTP.php';
//BEACHTUNG!!!!!ATTENTION

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Mailer = "smtp";
$senderEmail = "samosiesglobal@gmail.com";
$senderPw = "Samosies123";
//
$mail->SMTPDebug  = 0;  
$mail->SMTPAuth   = TRUE;
$mail->SMTPSecure = "tls";
$mail->Port       = 587;
$mail->Host       = "smtp.gmail.com";
$mail->Username   = $senderEmail;
$mail->Password   = $senderPw;

$mail->IsHTML(true);
$mail->AddAddress($email, $username);
$mail->SetFrom($senderEmail, "SAMOSIES");
$mail->AddReplyTo($email, $username);
$mail->AddCC($email, "cc-recipient-name");
$mail->Subject = "SAMOSIES your Receipt";
$content = $emailContent ;

$mail->MsgHTML($content); 

//incase email doesnt send

if(!$mail->Send()) {
  echo "Error while sending Email.";
  var_dump($mail);
	}
 else {
  echo "Email sent successfully " . $username . " " . $first . " " . $last ." " . $email;
}


?><?php /**PATH D:\XAMPP\new_web_project\resources\views/MailScript_SamPer.blade.php ENDPATH**/ ?>