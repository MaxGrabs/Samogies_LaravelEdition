<?php include 'D:\XAMPP\new_web_project\resources\views\SQL_SamPer\connectSqli.blade.php'; ?>
<!--BEACHTUNG!!!!!ATTENTION ^^ CHANGE TO ABSOLUTE PATHING -->

<html>

<head>
    <title>PHP Login Form with Password Encryption</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>

<body>
    <?php 
        if (!isset($_GET["login"])) {
    ?>
    <br /><br />
    <div class="container" style="width:500px;">
        <h3 align="center">Samosies Login Form </h3>
		<img src="ultimate_icon.png" alt="logo">
        <br />
        <h3 align="center">Login</h3>
        <br />

        
        <form method="get" action="<?php echo $_SERVER['PHP_SELF'] ?>">
            <label>Enter Username</label>
            <input type="text" name="username" class="form-control" />
            <br />
            <label>Enter Password</label>
            <input type="password" name="password" class="form-control" />
            <br />
            <input type="submit" name="login" value="Login" class="btn btn-info" />
            <br />
            <p align="center"><a href="register">Register</a></p>
        </form>
        </div>
        <?php 
            } 
            else { 
                $username=$_GET["username"];
                $passw=$_GET["password"];
				  $passw=md5($passw);
				
				echo "welcome " . $username;
                
                $sql = "SELECT * FROM samper_tbl WHERE usern ='$username' AND pass = '$passw' ";
				
				$result = mysqli_query($conn,$sql);
			

				if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
							$Id = $row["id"];
							$first = $row["fname"];
							$last = $row["lname"];
               
        ?>
					<?php 
							
								
								
								
							
							
							
							session_start();
							return redirect()->to('http://localhost:8080/store')->send();
							//header("Location: http://localhost:8080/store");
							$_SESSION["username"] = $username;
							$_SESSION["id"] = $Id;
							
							
					}
					?>
					
				
            
            </div>
					
        <?php
				}
				else{
					echo "Invalid username and or Password";
				}
			
        $conn = null;
			}
    
        ?>
            



</body>

</html><?php /**PATH D:\XAMPP\new_web_project\resources\views/Login_SamPer.blade.php ENDPATH**/ ?>