<!DOCTYPE html>
<?php include 'D:\XAMPP\new_web_project\resources\views\SQL_SamPer\connectsqli.blade.php'; ?>
<!--BEACHTUNG!!!!!ATTENTION ^^ CHANGE TO ABSOLUTE PATHING -->
<html lang="en">

<head>
<title></title>

<meta charset="utf-8">


<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
table, th, td {
  border: 1px solid black;
  padding: 3px;
  
}
input[type=number]{
	text align: center;
}

</style>



</head>
<body>

<?php
session_start();
echo "<h1> Hello, " . $_SESSION["username"] .  "</h1>";

?>
	
<main id="lol">

<form action="confirm" method="get" style="margin: auto; width: 50%;">

<h1>Pierogies</h1>
<p>Pierogies sold by the dozen (12)</p>
<p style = "padding-left: 350px;">Quantity</p>
<table>

<?php
for($x = 1; $x <=6; $x++){
$sql = "SELECT * FROM menus_tbl WHERE Id=" . $x;
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
	 while($row = $result->fetch_assoc()) {
echo "<tr>" . 
		"<th>" . "<strong>" . $row["Name"]. "</strong>" . "</th> " .
		"<td>" . $row["Description"] . "</td>" .
		"<td>" . " $ ". $row["Price"] .'<input type="number"  name =' . $row["Id"] . ' min="0" max="20">' . "</td>" . 
		"</tr>" ;
	 }
}
}
?>

</table>
<br>


<h1>SaMoSaS</h1>
<p>Samosas are sold by Half dozen(6)</p>
<table>
<?php
for($x = 7; $x <=11; $x++){
$sql = "SELECT * FROM menus_tbl WHERE Id=" . $x;
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
	 while($row = $result->fetch_assoc()) {
echo "<tr>" . 
		"<th>" . "<strong>" . $row["Name"]. "</strong>" . "</th> " . 
		"<td>" . $row["Description"] . "</td>" . 
		"<td>" . " $ ". $row["Price"] .'<input type="number"  name =' . $row["Id"] . ' min="0" max="20">' . "</td>" . 
		"</tr>" ;
	 }
}
}
?>

</table>
<br>


<h1>Sauces</h1>
<table>
<?php
for($x = 12; $x <=13; $x++){
$sql = "SELECT * FROM menus_tbl WHERE Id=" . $x;
$result = mysqli_query($conn,$sql);
if ($result->num_rows > 0) {
	 while($row = $result->fetch_assoc()) {
echo "<tr>" . 
		"<th>" . "<strong>" . $row["Name"]. "</strong>" . "</th> " . 
		"<td>" . $row["Description"] . "</td>" . 
		"<td>" . " $ ". $row["Price"] .'<input type="number"  name =' . $row["Id"] . ' min="0" max="20">' . "</td>" . 
		"</tr>" ;
	 }
}
}

?>

</table>
 <input type="submit" name="Buy" value="Buy Now" class="btn btn-info" />
			
			
</form>


</main>

<footer>

</footer>
</body>
</html>
