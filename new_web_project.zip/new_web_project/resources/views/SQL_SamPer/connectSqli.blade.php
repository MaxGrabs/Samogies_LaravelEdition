<?php

$dbhost = 'localhost:3306';
$dbuser = 'root';
$dbpass = '';
$db     = 'php_samper';


$conn  = mysqli_connect($dbhost,$dbuser,'',$db);

if(! $conn){
    die('Could not connect connect: <br>');
}

echo 'Successfully Connected to DB <br>' ;




?>