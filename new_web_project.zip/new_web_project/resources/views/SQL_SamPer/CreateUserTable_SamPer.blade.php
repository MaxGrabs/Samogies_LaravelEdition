<?php include 'D:\XAMPP\new_web_project\resources\views\SQL_SamPer\Connect_SamPer.blade.php'; ?>
<!--BEACHTUNG!!!!!ATTENTION ^^ CHANGE TO ABSOLUTE PATHING -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    try {
        //1)dropping the table in case it exists
        $sql = "DROP TABLE IF EXISTS SAMPER_TBL";

        $conn->query($sql);
        echo "SAMPER_TBL table dropped!<br/>";


        //2)creating table
        $sql = "CREATE TABLE SAMPER_TBL (
        id INT(10) AUTO_INCREMENT PRIMARY KEY,
        fname VARCHAR(125) NOT NULL,
        lname VARCHAR(125) NOT NULL,
        usern VARCHAR(125) NOT NULL,
        pass VARCHAR(125) NOT NULL,
        mail VARCHAR(125) NOT NULL,
		address VARCHAR(225) NOT NULL,
		payment INT(16) NOT NULL
        )";

        $conn->query($sql);
        echo "Table SAMPER_TBL created successfully<br/>";


        //create users
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
    ?>

    <?php
    $conn = null;
    ?>
</body>

</html>