<?php include 'D:\XAMPP\new_web_project\resources\views\SQL_SamPer\Connect_SamPer.blade.php'; ?>
<!--BEACHTUNG!!!!!ATTENTION ^^ CHANGE TO ABSOLUTE PATHING -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    try {
        //1)dropping the table in case it exists
        $sql = "DROP TABLE IF EXISTS menus_tbl";

        $conn->query($sql);
        echo "menus_tbl table dropped!<br/>";


        //2)creating table
        $sql = "CREATE TABLE menus_tbl (
        Id INT(10) AUTO_INCREMENT PRIMARY KEY,
        Name VARCHAR(125) NOT NULL,
        Description TEXT(225) NOT NULL,
        Price DOUBLE(4,2) NOT NULL,
        Quantity INT(10) NOT NULL,
        typeOf VARCHAR(125) NOT NULL
		)";
		
		$sqlInsert = "
		
		INSERT INTO menus_tbl (Name, Description, Price, Quantity, typeOf)
		VALUES 
		    ('Classic Perogie','Potatoes and Cheese', 5.25, 100,'Per'),
			('Cheese','CHEESEY', 5.75, 100,'Per'),
			('Vegan','Potatoes and Cheese', 5.25, 100,'Pier'),
			('Inside out Max','Caramalized Onions and Bacon', 7.50, 100,'Per'),
			('Feeling Blue?','Our Signature Blueberry Pierogies', 5.25, 100,'Per'),
			('Haram','Pulled Pork', 6.25, 100,'Per'),
			
			('Classic Samosa','Potatoes Peas and Spices', 3.25, 100,'Sam'),
			('Paneer','Indian Cheese', 5.00, 100,'Sam'),
			('Samishas','Lamb Tikka Masala', 6.50, 100,'Sam'),
			('Hindu Sacrilige','Beef and Potatoes', 7.00, 100,'Sam'),
			('Spanokopia','Spinach and Cottage Cheese', 5.25, 100,'Sam'),
			
			('Sour Cream','Home made Sour Cream', 0.50, 100,'Sauce'),
			('Tamarind Sauce','Traditional Tamarind dipping Sauce', 0.5, 100,'Sauce')
			
			";
		
        
		
        $conn->query($sql);
        echo "Table menus_tbl created successfully<br/>";
		
		 $conn->query($sqlInsert);
        echo "Table menus_tbl Inserted successfully<br/>";
		


        //create users
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
    ?>

    <?php
    $conn = null;
    ?>
</body>

</html>
