<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Mailer = "smtp";

$mail->SMTPDebug  = 1;  
$mail->SMTPAuth   = TRUE;
$mail->SMTPSecure = "tls";
$mail->Port       = 587;
$mail->Host       = "smtp.gmail.com";
$mail->Username   = "mishanayar31@gmail.com";
$mail->Password   = "";
//erdoganrazbek@gmail.com
$mail->IsHTML(true);
$mail->AddAddress("mishanayar31@gmail.com", "cunt");
$mail->SetFrom("erdoganrazbek@gmail.com", " max");
$mail->AddReplyTo("mishanayar31@gmail.com", "cunt");
$mail->AddCC("notscaredaboutyou@gmail.com", "nigger adrian");
$mail->Subject = "Test is Test Email sent via Gmail SMTP Server using PHP Mailer";
$content = "<b>This is a Test Email sent via Gmail SMTP Server using PHP mailer class.</b>";

$mail->MsgHTML($content); 
if(!$mail->Send()) {
  echo "Error while sending Email.";
  var_dump($mail);
} else {
  echo "Email sent successfully";
}
?>